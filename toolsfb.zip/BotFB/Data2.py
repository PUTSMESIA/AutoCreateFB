import os, sys, re, time, json, random, uuid, requests, cloudscraper
from user2 import *
from random import choice as rc
from random import randint as rr
from datetime import datetime

#Kode Warna Ansci
m = "\033[0;31m"
h = "\033[0;32m"
k = "\033[0;33m"
b = "\033[0;34m"
u = "\033[0;35m"
p = "\033[0;37m"
italic = "\033[3m"
reset = "\033[0m"
   


def Get_Data(req):
  return {
    "__aaid": re.search('"USER_ID":"(\d+)"',str(req)).group(1),
    "__user": re.search('"USER_ID":"(\d+)"',str(req)).group(1),
    "__a": "1",
    "__req": rc(["1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","z"]),
    "__hs": re.search('"haste_session":"(.*?)"',str(req)).group(1),
    "dpr": "1",
    "__ccg": re.search('"connectionClass":"(.*?)"',str(req)).group(1),
    "__rev": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__s": "",
    "__hsi": re.search('"hsi":"(\d+)"',str(req)).group(1),
    "__dyn": "",
    "__csr": "",
    "fb_dtsg": re.search('"dtsg":{"token":"(.*?)"',str(req)).group(1),
    "jazoest": re.search('"initSprinkleValue":"(\d+)"',str(req)).group(1),
    "lsd": re.search('"lsd":"(.*?)"',str(req)).group(1),
 }
 
def Get_Data1(req, uid):
  return {
    "__aaid": re.search('"USER_ID":"(\d+)"',str(req)).group(1),
    "__user": f"{uid}",
    "__a": "1",
    "__req": rc(["1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","z"]),
    "__hs": re.search('"haste_session":"(.*?)"',str(req)).group(1),
    "dpr": "1",
    "__ccg": re.search('"connectionClass":"(.*?)"',str(req)).group(1),
    "__rev": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__s": "",
    "__hsi": re.search('"hsi":"(\d+)"',str(req)).group(1),
    "__dyn": "",
    "__csr": "",
    "fb_dtsg": re.search('"dtsg":{"token":"(.*?)"',str(req)).group(1),
    "jazoest": re.search('"initSprinkleValue":"(\d+)"',str(req)).group(1),
    "lsd": re.search('"lsd":"(.*?)"',str(req)).group(1),
 }


####Ini Semua Data Status#######
def DataStatus(req):
  return {
    "av": re.search('"actorID":"(.*?)"',str(req)).group(1),
    "__aaid": "0",
    "__user": re.search('"actorID":"(.*?)"',str(req)).group(1),
    "__a": "1",
    "__req": "y",
    "__hs": re.search('"haste_session":"(.*?)"',str(req)).group(1),
    "dpr": "2",
    "__ccg": re.search('"connectionClass":"(.*?)"',str(req)).group(1),
    "__rev": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__s": "",
    "__hsi": re.search('"hsi":"(\d+)"',str(req)).group(1),
    "__dyn": "",
    "__csr": "",
    "__comet_req": "15",
    "fb_dtsg": re.search('"dtsg":{"token":"(.*?)"',str(req)).group(1),
    "jazoest": re.search('&jazoest=(\d+)',str(req)).group(1),
    "lsd": re.search('"LSD",\[\],\{"token":"(.*?)"',str(req)).group(1),
    "__spin_r": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__spin_b": "trunk",
    "__spin_t": re.search('"__spin_t":(\d+)',str(req)).group(1),
  }


def GetDate(req):
  return {
    "av": re.search('__user=(\d+)',req).group(1),
    "__user": re.search('__user=(\d+)',req).group(1),
    "__a": "1",
    "__req": "19",
    "__hs": re.search('"haste_session":"(.*?)"',str(req)).group(1),
    "dpr": "2",
    "__ccg": re.search('"connectionClass":"(.*?)"',str(req)).group(1),
    "__rev": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__s": "",
    "__hsi": re.search('"hsi":"(\d+)"',str(req)).group(1),
    "__dyn": "",
    "__csr": "",
    "__comet_req": re.search('__comet_req=(\d+)',req).group(1),
    "fb_dtsg": re.search('"DTSGInitData",\[\],{"token":"(.*?)",',req).group(1),
    "jazoest": re.search('jazoest=(\d+)',req).group(1),
    "lsd": re.search('"LSD",\[\],{"token":"(.*?)"',str(req)).group(1),
    "__spin_r": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__spin_b": re.search('"__spin_b":"(.*?)"',req).group(1),
    "__spin_t": re.search('"__spin_t":(\d+)',req).group(1),
  }

def HetGet():
  return {
    'x-fb-connection-bandwidth': random.choice(['2e7', '3e7']),
    'x-fb-sim-hni': '4e4',
    'x-fb-net-hni': '4e4',
    'x-fb-connection-quality': 'EXCELLENT',
    'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
    'user-agent': f'{uak2}',
    'content-type': 'application/x-www-form-urlencoded',
    'x-fb-http-engine': 'Liger'
    }

def HetPost():
  return {
    'x-fb-connection-bandwidth': random.choice(['2e7', '3e7']),
    'x-fb-sim-hni': '4e4',
    'x-fb-net-hni': '4e4',
    'x-fb-connection-quality': 'EXCELLENT',
    'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
    'user-agent': f'{uak2}',
    'content-type': 'application/x-www-form-urlencoded',
    'x-fb-http-engine': 'Liger'
    }

def Getpw(req):
  return {
    "av": re.search('__user=(\d+)',req).group(1),
    "__user": re.search('__user=(\d+)',req).group(1),
    "__a": "1",
    "__req": "19",
    "__hs": re.search('"haste_session":"(.*?)"',str(req)).group(1),
    "dpr": "2",
    "__ccg": re.search('"connectionClass":"(.*?)"',str(req)).group(1),
    "__rev": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__s": "",
    "__hsi": re.search('"hsi":"(\d+)"',str(req)).group(1),
    "__dyn": "",
    "__csr": "",
    "__hsdp": "",
    "__hblp": "",
    "__comet_req": re.search('__comet_req=(\d+)',req).group(1),
    "fb_dtsg": re.search('"DTSGInitData",\[\],{"token":"(.*?)",',req).group(1),
    "jazoest": re.search('jazoest=(\d+)',req).group(1),
    "lsd": re.search('"LSD",\[\],{"token":"(.*?)"',str(req)).group(1),
    "__spin_r": re.search('"__spin_r":(\d+)',str(req)).group(1),
    "__spin_b": re.search('"__spin_b":"(.*?)"',req).group(1),
    "__spin_t": re.search('"__spin_t":(\d+)',req).group(1),
  }