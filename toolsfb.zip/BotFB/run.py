import os
import sys
import re
import json
import time
import requests
import random
import ipaddress
import subprocess
import datetime
import string
from faker import Faker
from rich import print as prints
from rich.tree import Tree
from bs4 import BeautifulSoup as parser
from random import choice as rc
import base64
from User import *
from Data import *
from resize import *
from user2 import *
from Data2 import *
import re
import os
import random
import string
import requests
import json
import hashlib
import uuid
import urllib.parse
import gzip
import time
from rich import print as prints
from uuid import uuid4
from io import BytesIO
from User import *
from faker import Faker
fake = Faker()
import requests, re, json, os, time, random, pytz, urllib.request, uuid, sys, string
from bs4 import BeautifulSoup as bs
from datetime import datetime
from faker import Faker
from rich import print
from rich import print
from rich.tree import Tree
from rich.panel import Panel
from rich.columns import Columns
from rich.console import Console
from rich.console import Group
from rich.align import Align
from rich.syntax import Syntax
from datetime import datetime
from rich import print
from rich.panel import Panel
from rich.prompt import Prompt
from time import sleep
from PIL import Image
import os
import io
import requests
import re
import random
import json
import urllib.request
from time import sleep as jeda
from time import strftime
from bs4 import BeautifulSoup as sop
from datetime import datetime
from time import sleep as slp
import os
import shutil
import random
import requests
from pathlib import Path

# Kode Warna
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m'
O = '\x1b[1;96m'
N = '\x1b[0m'
Z = "\033[1;30m"
m = "\033[0;31m"
p = "\033[0;37m"
h = "\033[0;32m"
b = "\033[34m"
k = "\033[33m"

#──────────────{ WAKTU }──────────────#
bulan = {'1':'January','2':'February','3':'March','4':'April','5':'May','6':'June','7':'July','8':'August','9':'September','10':'October','11':'November','12':'December'}
tgl = datetime.now().day
bln = bulan[(str(datetime.now().month))]
thn = datetime.now().year
tanggal = (str(tgl)+' '+str(bln)+' '+str(thn))
waktu = strftime('%H:%M:%S')
hari = datetime.now().strftime("%A")

class MAIN:
    def approval(self):
        os.system('clear')
        print(Panel(self.logo, subtitle="[bold red]● [bright_yellow]● [green1]●",
                    subtitle_align='left', title="[bold red]● [bright_yellow]● [green1]●",
                    title_align='right', width=102, padding=0, style="bold green1"))
        print(Panel(self.hx, width=100, padding=0, style="cyan"))

        print(Panel(' [green1]SELAMAT DATANG DI TOOLS AUTO CREATE',
                    subtitle="[bold red]❏ [bright_yellow]❏ [green1]❏",
                    subtitle_align='left', title="[bold red]❏ [bright_yellow]❏ [green1]❏",
                    title_align='right', width=102, padding=0, style="bold blue"))

        time.sleep(1)

        # Langsung masuk menu tanpa validasi lisensi
        self.menu()
    logo = """
[bold cyan]                  ██╗   ██╗██╗   ██╗██╗██████╗
[bold cyan]                  ██║   ██║██║   ██║██║██╔══██╗
[bold cyan]                  ██║   ██║██║   ██║██║██████╔╝
[bold cyan]                  ╚██╗ ██╔╝╚██╗ ██╔╝██║██╔═══╝
[bold cyan]                   ╚████╔╝  ╚████╔╝ ██║██║
[bold cyan]                    ╚═══╝    ╚═══╝  ╚═╝╚═╝              

          [green_yellow]THIS [dark_olive_gre]TOOLS [pale_green1] IS[dark_sea_green…] NOT FOR FREE
"""
    ll = str([hari,tanggal])
    hx = """  [bold cyan]OWNER[medium_cyan1]   ⟩[cyan][bold] Putzz€¥
  [bold cyan]Devloper[medium_cyan1]   ⟩[cyan][bold] Putzzx€¥
  [bold cyan]TANGGAL[medium_cyan1]  ⟩ [cyan]""" + ll

    def banner(self):
        os.system("clear")
        print(Panel(self.logo, subtitle="[bold red]● [bright_yellow]● [green1]●", subtitle_align='left', title="[bold red]● [bright_yellow]● [green1]●", title_align='right', width=102, padding=0, style="bold cyan"))
        print(Panel(self.hx, width=100, padding=0, style="bold cyan"))

    def menu(self):
        self.banner()
        menu_panel = Panel("""\
[bold cyan][[bold cyan1]1/A[bold cyan]][cyan] AUTO CREATE FB CHANGE GMAIL && AUTO SETPP
[bold cyan][[bold cyan1]4/D[bold cyan]][red] EXIT\
""", title="[reverse violet] TOOL MENU", style="bold cyan")

        print(Panel(menu_panel, subtitle="[bold cyan]┌─", subtitle_align='left', style="bold cyan"))
        choice = Console().input("   [bold cyan]└──> ")

        if choice.lower() in ["1", "a", "01"]:
            self.create()
        elif choice.lower() in ["2", "b", "02"]:
            self.create2()
        elif choice.lower() in ["3", "c", "03"]:
            print(Panel("[bold yellow]Fitur 3 masih dalam pengembangan (COMING SOON)", style="bold yellow"))
            time.sleep(2)
            self.menu()
        elif choice.lower() in ["4", "d", "04"]:
            print("Terima kasih telah menggunakan tools.")
            exit()
        else:
            self.menu()

    def input_gender(self):
        while True:
            console.print(Panel(" [bold blue][[bold green1]1/A[bold blue]] [bold green1]Laki-Laki\n [bold blue][[bold green1]2/B[bold blue]] [bold green1]Permpuan", subtitle='[bold green1]╭─────', subtitle_align='left', style="bold green1"))
            pilihan = console.input("   [bold green1]└──> ").strip().lower()

            if pilihan in ["1", "a"]:
                return 1  # Perempuan
            elif pilihan in ["2", "b"]:
                return 2  # Laki-laki
            else:
                console.print("[bold red] (!) Pilihan tidak valid. Masukkan hanya 1/A atau 2/B.\n")

    def create(self):
        global web_email, total, delay, passwords, email_input
        console = Console()
        # Menu awal
        self.banner()
        console.print(Panel("""[bold green1][[bold cyan]1/A[bold green1]][bold cyan] DATA
[bold green1][[bold cyan]2/B[bold green1]][bold cyan] WIFI""", title="[reverse green1] ALL NETWORK ", style="bold green1"))
        mthd = console.input("   [bold cyan]└──> ")
        self.banner()

        # Input jumlah akun
        console.print(Panel(" [bold cyan]BERAPA AKUN YANG INGIN DI BUAT?", subtitle='[bold green1]╭─────', subtitle_align='left', style="bold green1"))
        total = int(console.input("   [bold green]└──> ") or 40)
        self.banner()

        # Input password
        console.print(Panel(" [bold red]MASUKKAN PASSWORD UNTUK SEMUA AKUN", subtitle='[bold green1]╭─────', subtitle_align='left', style="bold green1"))
        passwords = console.input("   [bold green1]└──> ").strip()
        self.banner()

        print(Panel("""[green_yellow][[bold cyan1]1/A[green_yellow]][bold green] Laki-Laki
[green_yellow][[bold cyan1]2/B[green_yellow]][bold green] Perempuan""", title="[reverse purple] GENDER ", style="bold violet"))
        Vallgender = Console().input("   [bold blue]└──> ")

        if Vallgender.lower() in ["1", "a", "01"]:
            genderr = "M"
        elif Vallgender.lower() in ["2", "b", "02"]:
            genderr = "F"

        # Set nilai awal
        web_email = "4"
        delay = 5

        # Input email pertama kali
        email_input = ""
        while not email_input.strip():  # Repeat input until valid
            self.banner()
            console.print(Panel(" [bold yellow]MASUKKAN EMAIL GMAIL", subtitle='[bold green1]╭─────', subtitle_align='left', style="bold green1"))
            email_input = console.input("   [bold green1]└──> ").strip()
            self.banner()
            print(Panel(f" [bold cyan]ACCOUNT CREATING STARTED", style="bold green1"))
            print(Panel(f" [bold cyan]IF NO RESULT, TRY ON/OFF AIRPLANE MODE OR VPN 1.1.1.1", style="bold green1"))
            if not email_input:
                console.print("[yellow]Email tidak boleh kosong! Silakan masukkan email yang valid.[/yellow]")

        # Loop pembuatan akun
        self.genderr = genderr
        for i in range(total):
            Mulai(genderr)  # <-- Panggil fungsi buat akun

            if i != total - 1:
                time.sleep(1)
                user_input = console.input("\n[bold cyan]MASUKKAN EMAIL BARU / TEKAN ENTER: ").strip()
                if user_input:
                    email_input = user_input  # Ganti email jika ada input baru

class Authen:
    def __init__(self, cok, password, mail):
        self.session = requests.Session()
        self.cok = cok.strip()
        self.mail = mail
        self.passnya = password
        self.newpass = "esbatu88"
        self.usernya = uak2
        self.Encrypt()
        self.Fotopp()

    def Encrypt(self):
        try:
            headers = {
                'x-fb-connection-bandwidth': '3e7',
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'x-fb-connection-quality': 'EXCELLENT',
                'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
                'user-agent': f'{self.usernya}',
                'content-type': 'application/x-www-form-urlencoded',
                'x-fb-http-engine': 'Liger'
            }
            self.req = self.session.get("https://accountscenter.facebook.com/password_and_security/two_factor", headers=headers, cookies={"cookie":self.cok}).text
            self.uid = re.search('__user=(\d+)',self.req).group(1)
            self.client = re.search('"clientID":"(.*?)"',str(self.req)).group(1)
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            data = GetDate(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXAccountsCenterTwoFactorSelectMethodDialogQuery",
                "variables": json.dumps({
                    "account_id": "{}".format(self.uid),
                    "account_type": "FACEBOOK",
                    "interface": "FB_WEB"
                }),
                "server_timestamps": "true",
                "doc_id": "7291183827635193"
            })
            res = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok})
            js = json.loads(res.text)
            if "encrypted_context" in str(js):
                self.enc = re.search('"encrypted_context":"(.*?)"',str(js)).group(1)
                self.Enc_Text()
            else:
                self.A2F()
        except AttributeError: 
            pass

    def Enc_Text(self):
        try:
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "TwoStepVerificationRootQuery",
                "variables": json.dumps({
                    "encryptedContext": f"{self.enc}",
                    "isLoginChallenges": False,
                    "isPreAuthentication": False
                }),
                "server_timestamps": True,
                "doc_id": "9105594422819787"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok})
            js = json.loads(pos1.text)
            self.mask = re.search("'method_representation': '(.*?)'",str(js)).group(1)
            self.Sending()
        except Exception as e: 
            print(e)

    def Sending(self):
        try:
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useTwoStepVerificationSendCodeMutation",
                "variables": json.dumps({"encryptedContext":f"{self.enc}","challenge":"EMAIL","maskedContactPoint":f"{self.mask}"}),
                "server_timestamps": True,
                "doc_id": "7767429506681192"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok}).json()
            self.Kodenya()
        except Exception as e: 
            print(e)

    def Kodenya(self):
        try:
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            kodenya = input(f"{K} lnput Security Code: {P}")
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useTwoFactorLoginValidateCodeMutation",
                "variables": json.dumps({"code":{"sensitive_string_value":f"{kodenya}"},"method":"EMAIL","flow":"SECURED_ACTION","encryptedContext":f"{self.enc}","maskedContactPoint":f"{self.mask}","next_uri":None}),
                "server_timestamps": True,
                "doc_id": "9803196929706606"
            })
            pos11 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok}).json()
            self.pswd()
        except Exception as e: 
            print(e)

    def pswd(self):
        try:
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXPasswordReauthenticationMutation",
                "variables": json.dumps({"input":{"account_id":f"{self.uid}","account_type":"FACEBOOK","category_name":None,"password":{"sensitive_string_value":"#PWD_BROWSER:0:%s:%s"%(time.time(), self.passnya)},"actor_id":f"{self.uid}","client_mutation_id":"1"}}),
                "server_timestamps": True,
                "doc_id": "5864546173675027"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok}).json()
            self.addmail()
        except Exception as e: 
            print(e)

    def A2F(self):
        try:
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            data = GetDate(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useFXSettingsTwoFactorGenerateTOTPKeyMutation",
                "variables": json.dumps({
                    "input": json.dumps({
                        "client_mutation_id": "{}".format(self.client),
                        "actor_id": "{}".format(self.uid),
                        "account_id": "{}".format(self.uid),
                        "account_type": "FACEBOOK",
                        "device_id": "device_id_fetch_datr",
                        "fdid": "device_id_fetch_datr"
                    })
                }),
                "server_timestamps": "true",
                "doc_id": "28758817267095297"
            })
            pos = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok}).json()
            if "key_text" in str(pos):
                self.key = re.search("'key_text': '(.*?)'",str(pos)).group(1)
                self.xxx = self.key.replace(" ","")
                self.otpx = self.session.get(f"https://2fa.live/tok/{self.xxx}").json()["token"]
                print(Panel(f" [bold cyan]KEY A2F🔵: {self.key}", style="bold green1"))
                print(Panel(f" [bold cyan]KODE A2F🔵: {self.otpx}", style="bold green1"))
                self.Authenticator()
        except Exception as e: 
            print(e)

    def Authenticator(self):
        headers3 = {
            'X-Fb-Sim-Hni': '310270',
            'X-Fb-Net-Hni': '310260',
            'User-Agent': f'{self.usernya}',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Tigon-Is-Retry': 'False',
            'X-Fb-Rmd': 'state=NO_MATCH',
            'X-Fb-Device-Group': '1672',
            'X-Fb-Friendly-Name': '',
            'X-Fb-Request-Analytics-Tags': 'unknown',
            'Accept-Encoding': 'gzip, deflate',
            'X-Fb-Http-Engine': 'Liger',
            'X-Fb-Client-Ip': 'True',
            'X-Fb-Server-Cluster': 'True',
            'Content-Length': '653',
            'Connection': 'close'
        }
        data = Getpw(self.req)
        data.update({
            "fb_api_caller_class": "RelayModern",
            "fb_api_req_friendly_name": "useFXSettingsTwoFactorEnableTOTPMutation",
            "variables": json.dumps({
                "input": json.dumps({
                    "client_mutation_id": "{}".format(self.client),
                    "actor_id": "{}".format(self.uid),
                    "account_id": "{}".format(self.uid),
                    "account_type": "FACEBOOK",
                    "verification_code": "{}".format(self.otpx),
                    "device_id": "device_id_fetch_datr",
                    "fdid": "device_id_fetch_datr"
                })
            }),
            "server_timestamps": True,
            "doc_id": "7510262092430928"
        })
        pos2 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie":self.cok}).json()
        open(f"dataA2F.txt","a").write(f"{self.uid}\n{self.key}\n\n")
        console = Console()
        genderr = "F"
        user_input = console.input("\n[bold cyan]MASUKKAN EMAIL BARU / TEKAN ENTER: ").strip()
        if user_input:
            email_input = user_input  # Ganti email jika ada input baru
        Mulai(genderr)

class Mulai:
    def __init__(self, genderr):
        self.session = requests.Session()
        self.rands = ''.join(random.choice(string.digits) for _ in range(8))
        self.genderr = genderr
        self.email = email_input
        self.password = passwords # Password default
        self.passnya = self.password
        self.user = uak2
        self.usernya = uak2
        self.fName = self.random_name()  # Nama depan acak
        self.lName = self.random_name()  # Nama belakang acak
        self.birthday = self.random_birthday()  # Tanggal lahir acak
        self.register()  # Melakukan pendaftaran akun
        self.login()
        self.confirm()

    def get_ip_info(self):
        try:
            response = requests.get("https://ipinfo.io/json")
            response.raise_for_status()
            ip_info = response.json()
            prints("[bold green]INFORMASI IP[/bold green]")
            prints(f"[bold yellow]IP:[/bold yellow] {ip_info['ip']}")
            prints(f"[bold yellow]Lokasi:[/bold yellow] {ip_info['city']}/{ip_info['region']}")
            prints()
        except Exception as e:
            prints(f"[bold red]IP Info Error:[/bold red] {e}")
            exit()

    def random_noo(self):
        nomer = ['0811', '0812', '0813', '0815', '0817', '0818', '0819', '0821', '0822', '0831', '0832', '0851', '0852', '0853', '0856', '0857', '0858', '0859', '0871', '0877', '0878', '0881', '0882', '0888', '0889', '0891', '0893', '0895', '0896', '0897', '0898', '0899']
        return random.choice(nomer)

    # Fungsi untuk menghasilkan nama acak
    def random_name(self):
        names = ['wati', 'dewi', 'citra', 'indah', 'ayu', 'sari', 'fitri', 'nina', 'rini', 'lia', 'riana', 'vivi', 'pratiwi', 'mei', 'nita', 'julia', 'rika', 'wati', 'zara', 'lina', 'amelia', 'angela', 'yuni', 'anggun', 'sinta', 'maya', 'diana', 'putri', 'marina', 'febriani', 'sella', 'dwi', 'eni', 'ratna', 'gita', 'susi', 'farah', 'alma', 'yulia', 'nabila', 'erika', 'ratih', 'selly', 'endah', 'alisa', 'najwa', 'mita', 'devita', 'ruth', 'silvia', 'kezia', 'tina', 'widya', 'cindy', 'irma', 'arini', 'kristina', 'novita', 'ariana', 'maria', 'vanessa', 'gita', 'bilqis', 'siti', 'nursyifa', 'dhea', 'elya', 'lia', 'teresia', 'arisa', 'nindy', 'rhea', 'susilawati', 'veronica', 'febriana', 'tika', 'devi', 'kiki', 'andini', 'adella', 'diana', 'fiona', 'fatma', 'yuliana', 'evy', 'shinta', 'bella', 'laras', 'jessica', 'nana', 'erina', 'zaitun', 'rafi', 'alifa', 'nadin', 'juliana', 'tyas', 'tari', 'fitriani', 'melisa', 'utami', 'lia', 'anisa', 'linda', 'viona', 'siti', 'ahda', 'salma', 'nana', 'vivi', 'arini', 'susi', 'anya', 'regina', 'bunga', 'dania', 'syifa', 'damar', 'tiara', 'vivi', 'helena', 'joanna', 'syahira', 'putri', 'arini', 'elsa', 'rilly', 'raisa', 'adriani', 'yanti', 'kristin', 'fitriani', 'siva', 'adriana', 'winda', 'dinda', 'avril', 'yessica', 'wina', 'trista', 'klara', 'yuliana', 'paulina', 'melati', 'elisa', 'theresia', 'catharina', 'alia', 'syarifah', 'melina', 'melisa', 'vanessa', 'marisa', 'mira', 'susan', 'luna', 'calista', 'clarissa', 'aldiana', 'erina', 'hilda', 'santi', 'tessa', 'astari', 'risa', 'novy', 'marissa', 'sandya', 'firda', 'rara', 'indah', 'agustina', 'brina', 'lia', 'ari', 'kamelia', 'rani', 'tina', 'selvi', 'tari', 'anis', 'friska', 'wati', 'intan', 'pipi', 'tina', 'zetta', 'ati', 'ratih', 'tyas', 'jesica', 'firda', 'milka', 'evita', 'stella', 'rani', 'lalita', 'rini', 'zeti', 'najwa', 'astuti', 'cut', 'risa', 'naomi', 'pamela', 'angelina', 'kurnia', 'acil', 'madina', 'andini', 'karina', 'liza', 'vanesa', 'onnie', 'okta', 'kiki', 'rahma', 'raida', 'dina', 'yani', 'melina', 'anita', 'hani', 'iris', 'dheya', 'felita', 'fitria', 'devi', 'ariyanti', 'livia', 'samsi', 'ratna', 'stefanie', 'cynthia', 'prisca', 'tiara', 'angeline', 'amanda', 'melis', 'fanie', 'syifa', 'atika', 'marina', 'deliana', 'sherly', 'intan', 'devina', 'andrea', 'desy', 'tika', 'elsa', 'winda', 'devitri', 'sintia', 'hana', 'selvi', 'annisa', 'celi', 'tiara', 'adinda', 'syifa', 'inna', 'liana', 'rafia', 'mira', 'shinta', 'jemima', 'ratna', 'athira', 'yenni', 'della', 'vivi', 'devina', 'atiya', 'allya', 'kia', 'vera', 'ria', 'brina', 'melia', 'rina', 'citra', 'mya', 'putri', 'hera', 'nova', 'inara', 'cynthia', 'radiana', 'melis', 'wahyuni', 'afra', 'angela', 'florencia', 'zora', 'putra', 'indri', 'vita', 'yana', 'sari', 'putri', 'yuliana', 'rahmawati', 'hidayati', 'fitriani', 'wahyuni', 'ramadhani', 'wijayanti', 'astuti', 'mulyani', 'wijaya', 'tari', 'andari', 'rismayanti', 'prasetyo', 'malina', 'susilawati', 'rakhmawati', 'sugiharti', 'murni', 'ayu', 'darmawati', 'kurniati', 'ratnasari', 'fitriana', 'komalasari', 'pramudya', 'putriani', 'darmawan', 'suhartati', 'solihah', 'nugraheni', 'rani', 'rahma', 'anggraini', 'pratiwi', 'syahida', 'putriwati', 'yani', 'nurkhasanah', 'paramita', 'purwanti', 'dwiastuti', 'arianti', 'indrawati', 'kusmiyati', 'ratih', 'indriani', 'susanti', 'herminawati', 'kurniastuti', 'nayla', 'wulandari', 'melina', 'wulandari', 'rahmawati', 'putriwati', 'tanjung', 'nadira', 'fitriwati', 'pradewi', 'ramadhan', 'haryati', 'melinda', 'saraswati', 'nurjanah', 'sulamati', 'kumalasari', 'kaliswari', 'alfiani', 'siti', 'safitri', 'putrianti', 'yani', 'kelana', 'desti', 'kuswanti', 'herlina', 'estiani', 'zahrina', 'siwi', 'santika', 'alfi', 'desiana', 'noviyanti', 'widyasari', 'rizkyani', 'suryani', 'arini', 'rianti', 'ratnaningsih', 'eliani', 'zulfiani', 'kandari', 'tristiani', 'elvina', 'febriyanti', 'noviani', 'verawati', 'putriana', 'lewati', 'rahmaniah', 'sihombing', 'clara', 'esther', 'mira', 'novita', 'dwiwulan', 'dewi', 'fransiska', 'ramadhani', 'kusuma', 'tuti', 'pramudiati', 'olivia', 'rasyida', 'rini', 'haliyani', 'suryanti', 'trianti', 'narisa', 'taryani', 'rasidah', 'dinasari', 'melani', 'wati', 'gusti', 'priawati', 'ivani', 'juliani', 'nesri', 'ratnasari', 'seruni', 'bunga', 'pratomi', 'nisrina', 'fitriani', 'marlina', 'natalia', 'ratnadewi', 'andayani', 'riviana', 'siti', 'saharwati', 'ratnasih', 'purnawati', 'lina', 'miranti', 'rahmayani', 'rikawati', 'ariana', 'pramudiani', 'arnawati', 'tamara', 'mayanti', 'ratilawati', 'sesilia', 'amalia', 'tika', 'widyawati', 'kristanti', 'rizkia', 'tantri', 'resti', 'bayu', 'nuraeni', 'jannati', 'garini', 'vitriani', 'putrisari', 'novy', 'shariah', 'gita', 'prasepti', 'zahriah', 'merina', 'vivi', 'almira', 'tyas', 'sofiwati', 'armida', 'ashifa', 'muharatni', 'ramadhiani', 'nuryani', 'susilawati', 'pamela', 'desmi', 'kusmaria', 'jessica', 'septi', 'fariana', 'herlin', 'fina', 'lisna', 'katriana', 'faizah', 'fadila', 'ramadani', 'tian', 'fitratul', 'wafira', 'seniwati', 'destiana', 'selena', 'khasanah', 'devi', 'kelian', 'farah', 'salimah', 'permata', 'marini', 'rinawati', 'budiati', 'utami', 'marchita', 'ceria', 'saharina', 'salma', 'phiani', 'farina', 'mustikaningsih', 'nastiti', 'sundari', 'zahra', 'xenovia', 'nabila']
        return random.choice(names)

    # Fungsi untuk menghasilkan tanggal lahir acak
    def random_birthday(self):
        return f"19{random.randint(85, 99)}-{random.randint(1, 12)}-{random.randint(1, 28)}"

    # Fungsi untuk menghasilkan ID mesin acak
    def random_machine_id(self):
        return ''.join(random.choice(string.ascii_uppercase + string.digits + string.ascii_lowercase) for _ in range(24))

    # Fungsi untuk mendaftar akun Facebook
    def register(self):
        data = sorted([
            ('email', self.email),
            ('firstname', self.fName),
            ('lastname', self.lName),
            ('gender', self.genderr),
            ('password', self.password),
            ('birthday', self.birthday),
            ('return_multiple_errors', 'true'),
            ('attempt_login', 'true'),
            ('reg_instance', fake.uuid4()),
            ('device_id', fake.uuid4()),
            ('family_device_id', fake.uuid4()),
            ('skip_session_info','true'),
            ('format', 'json'),
            ('advertising_id', fake.uuid4()),
            ('meta_inf_fbmeta', 'NO_FILE'),
            ('locale', 'id_ID'),
            ('client_country_code', 'ID'),
            ('method', 'user.register'),
            ('fb_api_req_friendly_name', 'registerAccount'),
            ('fb_api_caller_class', 'com.facebook.registration.fragment.RegistrationCreateAccountFragment'),
            ('api_key', '882a8490361da98702bf97a021ddc14d')
        ])

        # Membuat tanda tangan untuk data
        sig = "".join([f"{key}={value}" for key, value in data])
        sig += "62f8ce9f74b12f84c123cc23437a4a32"
        m = hashlib.md5()
        m.update(sig.encode('utf-8'))
        data.append(("sig", m.hexdigest()))

        headers = {
            'X-Fb-Connection-Type': 'mobile.LTE',
            'X-Fb-Net-Hni': '310260',
            'X-Fb-Sim-Hni': '310260',
            'X-Fb-Net-Sid': '',
            'X-Fb-Http-Engine': 'Apache',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Encoding': 'gzip',
            'User-Agent': f'{self.user}'
        }

        # Membuat session untuk melacak cookies
        session = requests.Session()

        # Mengompresi data dan mengirim permintaan POST
        out = BytesIO()
        with gzip.GzipFile(fileobj=out, mode="w") as f:
            f.write(urllib.parse.urlencode(data).encode('utf-8'))

        resp = session.post("https://b-api.facebook.com/method/user.register", headers=headers, data=out.getvalue())

        if resp.status_code == 200:
            try:
                # Cek jika JSON diterima dengan baik
                response_json = json.loads(resp.text)
                if 'new_user_id' in response_json:
                    self.uid = response_json['new_user_id']
                    print(Panel(f" [bold cyan]ACCOUNT ACCESIBLE", style="bold green1"))
                    name = f"{self.fName} {self.lName}"
                    info_akun = f"""
[bold cyan]✅ NAMA AKUN : [bold green1]{name}✅
[bold cyan]🆔 IDUSER  : [bold green1]{self.uid}
[bold cyan]🗝️ PASWD  : [bold green1]{self.passnya}
"""
                    print(Panel(info_akun, title="[bold green1]AKUN INFO[/bold green1]", border_style="green1"))
                else:
                    print(response_json)
                    exit()
            except json.JSONDecodeError:
                print("Error decoding the JSON response.")
        else:
            print(f"Failed to get a response from the server. Status code: {resp.status_code}")
            print("Response:", resp.text)

    def login(self):
        head = {
            'Host': 'b-graph.facebook.com',
            'X-Fb-Connection-Quality': 'EXCELLENT',
            'Authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
            'User-Agent': f'{self.user}',
            'X-Tigon-Is-Retry': 'false',
            'X-Fb-Friendly-Name': 'authenticate',
            'X-Fb-Connection-Bandwidth': str(random.randrange(70000000, 80000000)),
            'Zero-Rated': '0',
            'X-Fb-Net-Hni': str(random.randrange(50000, 60000)),
            'X-Fb-Sim-Hni': str(random.randrange(50000, 60000)),
            'X-Fb-Request-Analytics-Tags': '{"network_tags":{"product":"350685531728","retry_attempt":"0"},"application_tags":"unknown"}',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Fb-Connection-Type': 'WIFI',
            'X-Fb-Device-Group': str(random.randrange(4700, 5000)),
            'Priority': 'u=3,i',
            'Accept-Encoding': 'gzip, deflate',
            'X-Fb-Http-Engine': 'Liger',
            'X-Fb-Client-Ip': 'true',
            'X-Fb-Server-Cluster': 'true',
            'Content-Length': str(random.randrange(1500, 2000))
        }
        data = {
            'adid': str(uuid.uuid4()),
            'format': 'json',
            'device_id': str(uuid.uuid4()),
            'email': self.uid,
            'password': '#PWD_FB4A:0:{}:{}'.format(str(time.time())[:10], self.password),
            'generate_analytics_claim': '1',
            'community_id': '',
            'linked_guest_account_userid': '',
            'cpl': True,
            'try_num': '1',
            'family_device_id': str(uuid.uuid4()),
            'secure_family_device_id': str(uuid.uuid4()),
            'credentials_type': 'password',
            'account_switcher_uids': [],
            'fb4a_shared_phone_cpl_experiment': 'fb4a_shared_phone_nonce_cpl_at_risk_v3',
            'fb4a_shared_phone_cpl_group': 'enable_v3_at_risk',
            'enroll_misauth': False,
            'generate_session_cookies': '1',
            'error_detail_type': 'button_with_disabled',
            'source': 'login',
            'machine_id': ''.join([
                random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
                for i in range(24)
            ]),
            'jazoest': str(random.randrange(22000, 23000)),
            'meta_inf_fbmeta': 'V2_UNTAGGED',
            'advertiser_id': str(uuid.uuid4()),
            'encrypted_msisdn': '',
            'currently_logged_in_userid': '0',
            'locale': 'id_ID',
            'client_country_code': 'ID',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'Fb4aAuthHandler',
            'api_key': '882a8490361da98702bf97a021ddc14d',
            'sig': hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()[:32],
            'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        }
        pos = requests.post('https://b-graph.facebook.com/auth/login', data=data, headers=head)
        if pos.status_code == 200:
            try:
                response_json = json.loads(pos.text)
                if 'session_cookies' in response_json:
                    for cookie in response_json['session_cookies']:
                        if cookie['name'] == 'c_user':
                            self.c_user = cookie['value']
                        elif cookie['name'] == 'xs':
                            self.xs = cookie['value']
                        elif cookie['name'] == 'fr':
                            self.fr = cookie['value']
                        elif cookie['name'] == 'datr':
                            self.datr = cookie['value']
                    self.cok = f"datr={self.datr}; fr={self.fr}; c_user={self.c_user}; xs={self.xs}"
                    self.token = response_json['access_token']
                    print()
                    open(f"cokies_{self.password}.txt","a").write(f"{self.cok}\n")
                else:
                    print("Access token tidak ditemukan")
                    print()
                    open(f"gagal_login.txt","a").write(f"{self.email}\n")
            except json.JSONDecodeError:
                print("Error decoding the JSON response.")
        else:
            print(f"Failed to get a response from the server. Status code: {pos.status_code}")
            open(f"gagal_login.txt","a").write(f"{self.email}\n")

    def confirm(self):
        print(Panel("""[bold blue]KODE VERIFIKASI:""", title="[reverse green1]MASUKAN KODE VERIFIKASI ", style="bold green1"))
        self.code = Console().input("   [bold green1]└──> ")

        # Data yang dikirimkan untuk konfirmasi
        data = {
            'normalized_contactpoint': self.email,
            'contactpoint_type': 'EMAIL',
            'code': self.code,
            'source': 'ANDROID_DIALOG_API',
            'surface': 'hard_cliff',
            'generate_session_cookies': '1',
            'format': 'json',
            'locale': 'id_ID',
            'client_country_code': 'ID',
            'method': 'user.confirmcontactpoint',
            'fb_api_req_friendly_name': 'confirmContactpoint',
            'fb_api_caller_class': 'com.facebook.confirmation.fragment.ConfCodeInputFragment',
        }

        headers = {
            'Authorization': f'OAuth {self.token}',
            'X-Fb-Connection-Type': 'mobile.LTE',
            'X-Fb-Http-Engine': 'Apache',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Encoding': 'gzip',
            'User-Agent': f'{self.user}'
        }

        # Mengompresi data dan mengirim permintaan POST
        out = BytesIO()
        with gzip.GzipFile(fileobj=out, mode="w") as f:
            f.write(urllib.parse.urlencode(data).encode('utf-8'))

        try:
            r = requests.post("https://b-api.facebook.com/method/user.confirmcontactpoint", headers=headers, data=out.getvalue())
            try:
                response_json = r.json()  # Jika responsnya berupa JSON
                print("Response JSON:", response_json)
            except ValueError:
                print("Response bukan JSON.")

            if r.text == "true":
                print(Panel(f" [bold green1]EMAIL UTAMA BERHASIL DI VERIFIKASI", style="bold green1"))
                #time.sleep(10)
                self.Authen2(self.cok)
              #  time.sleep(10)
                open(f"cokies_{self.password}.txt","a").write(f"{self.cok}\n")
                open(f"{self.password}.txt","a").write(f"{self.uid}\n")
             #   self.contact()
            else:
                print("[info] Terjadi kesalahan saat mengkonfirmasi email.")
        except requests.exceptions.RequestException as e:
            print(f"[error] Terjadi kesalahan saat mengirim permintaan: {e}")

    def header3(self):
        return {
            'X-Fb-Sim-Hni': '310270',
            'X-Fb-Net-Hni': '310260',
            'User-Agent': f'{self.usernya}',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Tigon-Is-Retry': 'False',
            'X-Fb-Rmd': 'state=NO_MATCH',
            'X-Fb-Device-Group': '1672',
            'X-Fb-Friendly-Name': '',
            'X-Fb-Request-Analytics-Tags': 'unknown',
            'Accept-Encoding': 'gzip, deflate',
            'X-Fb-Http-Engine': 'Liger',
            'X-Fb-Client-Ip': 'True',
            'X-Fb-Server-Cluster': 'True',
            'Content-Length': '653',
            'Connection': 'close'
        }

    def headerxx(self):
        return {
            'Host': 'akunlama.com',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'accept': 'application/json, text/plain, */*',
            'sec-ch-ua-mobile': '?1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'referer': f'https://akunlama.com/inbox/{self.cok}/list',
            'accept-language': 'id-ID,id;q=0.9'
        }

    def Encrypt(self):
        try:
            headers = {
                'x-fb-connection-bandwidth': '3e7',
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'x-fb-connection-quality': 'EXCELLENT',
                'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
                'user-agent': f'{self.usernya}',
                'content-type': 'application/x-www-form-urlencoded',
                'x-fb-http-engine': 'Liger'
            }
            self.req = self.session.get(
                "https://accountscenter.facebook.com/password_and_security/two_factor",
                headers=headers,
                cookies={"cookie": self.cok}
            ).text

            self.uid = re.search('__user=(\d+)', self.req).group(1)
            self.client = re.search('"clientID":"(.*?)"', self.req).group(1)
            self.contact()

        except Exception as e:
            prints(f"[red]Encrypt error:[/red] {e}")
            with open("cookies_error.txt", "a") as error_cookies:
                error_cookies.write(f'{self.cok}\n')

    def contact(self):
        try:
            form_data = Getpw(self.req)
            form_data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXAccountsCenterContactPointRootQuery",
                "variables": json.dumps({"interface": "FB_WEB"}),
                "server_timestamps": True,
                "doc_id": "9849298431773678"
            })

            response = self.session.post(
                "https://accountscenter.facebook.com/api/graphql/",
                data=form_data,
                headers=self.header3(),
                cookies={"cookie": self.cok}
            )

            response_json = response.json()

            emails = [
                cp['normalized_contact_point']
                for cp in response_json['data']['fxcal_settings']['node']['all_contact_points']
                if cp['contact_point_type'] == 'EMAIL'
            ]

            self.fakemail = input("masukkan fakemail : ")

            print(Panel(f" [bold cyan]MENAMBAHKAN EMAIL..", style="bold green1"))
            self.fakemail

        except Exception as e:
            prints(f"[red]Terjadi error:[/red] {e}")
            with open("error.txt", "a") as error_file:
                error_file.write(f'{self.cok}\n')

    def mulai(self):
        try:
            data = Getpw(self.req)
            self.otpx = "000000"
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useFXSettingsTwoFactorEnableTOTPMutation",
                "variables": json.dumps({
                    "input": json.dumps({
                        "client_mutation_id": "{}".format(self.client),
                        "actor_id": "{}".format(self.uid),
                        "account_id": "{}".format(self.uid),
                        "account_type": "FACEBOOK",
                        "verification_code": "{}".format(self.otpx),
                        "device_id": "device_id_fetch_datr",
                        "fdid": "device_id_fetch_datr"
                    })
                }),
                "server_timestamps": True,
                "doc_id": "7510262092430928"
            })
            res = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok})
            js = json.loads(res.text)
            if "encrypted_context" in str(js):
                self.enc = re.search('"encrypted_context":"(.*?)"', str(js)).group(1)
                self.Enc_Text()
            else:
                self.addmail()
        except AttributeError:
            pass

    def Enc_Text(self):
        try:
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "TwoStepVerificationRootQuery",
                "variables": json.dumps({
                    "encryptedContext": f"{self.enc}",
                    "isLoginChallenges": False,
                    "isPreAuthentication": False
                }),
                "server_timestamps": True,
                "doc_id": "9105594422819787"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok})
            js = json.loads(pos1.text)
            self.mask = re.search("'method_representation': '(.*?)'", str(js)).group(1)
            if self.mask:
                print(self.mask)
                self.Sending()
            else:
                self.mulai()
        except Exception as e:
            print(e)

    def Sending(self):
        try:
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useTwoStepVerificationSendCodeMutation",
                "variables": json.dumps({"encryptedContext": f"{self.enc}", "challenge": "EMAIL", "maskedContactPoint": f"{self.mask}"}),
                "server_timestamps": True,
                "doc_id": "7767429506681192"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok}).json()
            self.Kodenya()
        except Exception as e:
            print(e)

    def Kodenya(self):
        try:
            print(Panel(" [bold cyan]MASUKAN KODE KEAAMANAN", subtitle='[bold green1]╭─────', subtitle_align='left', style="bold green1"))
            kodenya = Console().input("   [bold green1]└──> ")
            if not kodenya:
                print(f"{M}Security code is required. Exiting...{P}")
                exit()

            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useTwoFactorLoginValidateCodeMutation",
                "variables": json.dumps({
                    "code": {"sensitive_string_value": f"{kodenya}"},
                    "method": "EMAIL",
                    "flow": "SECURED_ACTION",
                    "encryptedContext": f"{self.enc}",
                    "maskedContactPoint": f"{self.mask}",
                    "next_uri": None
                }),
                "server_timestamps": True,
                "doc_id": "9803196929706606"
            })
            pos11 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok}).json()
            self.addmail()
        except Exception as e:
            print(e)

    def addmail(self):
        try:
            self.newmoil = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
            self.newmail = input("masukkan fakemail : ")
            self.babah = input("masukkan kode fakemail ya :")
            print(Panel(f" [bold cyan]EMAIL BARU: {self.newmail}", style="bold green1"))
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXAccountsCenterAddContactPointMutation",
                "variables": json.dumps({
                    "country": "US",
                    "contact_point": f"{self.fakemail}",
                    "contact_point_type": "email",
                    "selected_accounts": [f"{self.uid}"],
                    "family_device_id": "device_id_fetch_datr",
                    "client_mutation_id": "mutation_id_1739708552117"
                }),
                "server_timestamps": True,
                "doc_id": "6970150443042883"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok}).json()
            time.sleep(3)
        except Exception as e:
            print(e)

    def akunlama(self):
        try:
            response1 = self.session.get(f'https://akunlama.com/api/v1/mail/list?recipient={self.newmoil}', headers=self.headerxx()).text
            time.sleep(3)
            cariotp = self.session.get(f'https://akunlama.com/api/v1/mail/list?recipient={self.newmoil}', headers=self.headerxx()).text
            time.sleep(5)
            cariotp2 = self.session.get(f'https://akunlama.com/api/v1/mail/list?recipient={self.newmoil}', headers=self.headerxx()).text
            key = re.search(r'"key":"(.*?)","env"',str(cariotp2)).group(1)
            buka = self.session.get(f'https://akunlama.com/api/v1/mail/getHtml?region=us-east4&key={key}', headers=self.headerxx()).text
            kode = re.search(r'kode konfirmasi ini:  (.*?) \ <\/span',str(buka)).group(1)
            self.kode = kode.strip()
            print(self.kode)
            self.replace()
        except Exception as e:
            self.akunbaru()
            open("akunbaru.txt", "a").write(f"\n{self.newmail}\n")
    def akunbaru(self):
        try:
            response1 = self.session.get(f'https://akunlama.com/api/v1/mail/list?recipient={self.newmoil}', headers=self.headerxx()).text
            cariotp = self.session.get(f'https://akunlama.com/api/v1/mail/list?recipient={self.newmoil}', headers=self.headerxx()).text
            kode = re.search(r'"subject":"(.*?) adalah kode Anda untuk mengonfirmasi email ini"',str(cariotp)).group(1)
            self.kode = kode.strip()
            print(self.kode)
            self.replace()
        except Exception as e:
            print(f"###{M}MASUKAN KODE MANUAL{P}###")
            while True:
                self.kode = input('Kode: ')
                if self.kode.strip() != '':
                    break
                print("Kode tidak boleh kosong. Silakan coba lagi.")
            self.replace()


    def replace(self):
        try:
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXAccountsCenterContactPointConfirmationDialogVerifyContactPointMutation",
                "variables": json.dumps({
                    "contact_point": f"{self.newmail}",
                    "contact_point_type": "email",
                    "pin_code": f"{self.babah}",
                    "selected_accounts": [f"{self.uid}"],
                    "family_device_id": "device_id_fetch_datr",
                    "client_mutation_id": "mutation_id_1739711729105",
                    "contact_point_event_type": "REPLACE",
                    "normalized_contact_point_to_replace": f"{self.fakemail}"
                }),
                "server_timestamps": True,
                "doc_id": "8108292719198518"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok})
            js = json.loads(pos1.text)
            if "FXCALSettingsMutationReturnDataSuccess" in str(js):
                with open(f"replace_{self.passnya}.txt", "a") as hasil:
                    hasil.write(self.cok + "\n")
            else:
                self.enc = re.search('"encrypted_context":"(.*?)"', str(js)).group(1)
                self.Enc_Text()
        except AttributeError:
            pass

    def okeh(self):
        try:
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXAccountsCenterContactPointMutationResultsQuery",
                "variables": json.dumps({
                    "contact_point_event_type": "DELETE",
                    "contact_point_type": "EMAIL",
                    "interface": "FB_WEB",
                    "normalized_contact_point": f"{self.fakemail}"
                }),
                "server_timestamps": True,
                "doc_id": "9564621703593431"
            })
            pos1 = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=self.header3(), cookies={"cookie": self.cok}).json()
            print(pos1)
        except Exception as e:
            print(e)

    def Authen2(self, cok):
        self.session = requests.Session()
        self.cok = cok
        self.usernya = uak3
        self.Encrypt2()
        self.Fotopp()

    def Encrypt2(self):
        try:
            headers = {
                'x-fb-connection-bandwidth': '3e7',
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'x-fb-connection-quality': 'EXCELLENT',
                'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
                'user-agent': f'{self.usernya}',
                'content-type': 'application/x-www-form-urlencoded',
                'x-fb-http-engine': 'Liger'
            }
            self.req = self.session.get("https://accountscenter.facebook.com/password_and_security/two_factor", headers=headers, cookies={"cookie": self.cok}).text
            if not self.req:
                raise ValueError("Response is empty.")
            self.uid = re.search('__user=(\d+)', self.req).group(1)
            self.client = re.search('"clientID":"(.*?)"', str(self.req)).group(1)
            headers3 = {
                'X-Fb-Sim-Hni': '310270',
                'X-Fb-Net-Hni': '310260',
                'User-Agent': f'{self.usernya}',
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Tigon-Is-Retry': 'False',
                'X-Fb-Rmd': 'state=NO_MATCH',
                'X-Fb-Device-Group': '1672',
                'X-Fb-Friendly-Name': '',
                'X-Fb-Request-Analytics-Tags': 'unknown',
                'Accept-Encoding': 'gzip, deflate',
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '653',
                'Connection': 'close'
            }
            data = GetDate(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "FXAccountsCenterTwoFactorSelectMethodDialogQuery",
                "variables": json.dumps({
                    "account_id": f"{self.uid}",
                    "account_type": "FACEBOOK",
                    "interface": "FB_WEB"
                }),
                "server_timestamps": "true",
                "doc_id": "7291183827635193"
            })
            res = self.session.post("https://accountscenter.facebook.com/api/graphql/", data=data, headers=headers3, cookies={"cookie": self.cok})
            js = json.loads(res.text)
            if "encrypted_context" in str(js):
                self.enc = re.search('"encrypted_context":"(.*?)"', str(js)).group(1)
            else:
                self.A2F()
        except AttributeError:
            pass

    def Fotopp(self):
        headers3 = {
            'X-Fb-Sim-Hni': '310270',
            'X-Fb-Net-Hni': '310260',
            'User-Agent': f'{self.usernya}',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Tigon-Is-Retry': 'False',
            'X-Fb-Rmd': 'state=NO_MATCH',
            'X-Fb-Device-Group': '1672',
            'X-Fb-Friendly-Name': '',
            'X-Fb-Request-Analytics-Tags': 'unknown',
            'Accept-Encoding': 'gzip, deflate',
            'X-Fb-Http-Engine': 'Liger',
            'X-Fb-Client-Ip': 'True',
            'X-Fb-Server-Cluster': 'True',
            'Content-Length': '653',
            'Connection': 'close'
        }
        compress_random_image("src/profile_pic", "src/foto2/ouput.jpg", 100)
        folder_path = "src/profile_pic"
        photo_list = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]

        if not photo_list:
            raise ValueError("No photos found in the specified folder.")

        p_pic_s = os.path.join(folder_path, random.choice(photo_list))
        p_pic = os.path.getsize(p_pic_s)

        with open(p_pic_s, "rb") as imagefile:
            convert = base64.b64encode(imagefile.read())
            self.image = convert.decode()

        # Check if self.req is None before proceeding
        if self.req is None:
            print("Error: self.req is None. Skipping to next iteration.")
            return  # Skip this iteration if self.req is None

        try:
            data = Getpw(self.req)
            data.update({
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useFXIMUpdateProfilePhotoMutation",
                "variables": json.dumps({
                    "client_mutation_id": f"{self.client}",
                    "identity_ids": f"{self.uid}",
                    "image_data": f"data:image/png;base64,{self.image}",
                    "profile_photo_metadata": None,
                    "family_device_id": "device_id_fetch_datr"
                }),
                "server_timestamps": True,
                "doc_id": "28668573429455973"
            })
            pos3 = self.session.post(
                "https://accountscenter.facebook.com/api/graphql/",
                data=data,
                headers=headers3,
                cookies={"cookie": self.cok}
            )
            jsn = json.loads(pos3.text)

            if "image_uri" in str(jsn):
                open(f"{self.passnya}.txt", "a").write(f"{self.uid}\n")
                open("datacok.txt", "a").write(f"{self.uid}    {self.passnya}     {self.cok}\n")
                tree = Tree('[bold white][ UPLOAD FOTO PROFILE SUKSES ]')
                tree.add(f'[bold green]{p_pic_s}')
                tree.add(f'[bold green]{self.usernya}')
                prints(tree)
                self.Encrypt()
        except Exception as e:
            print(f"Error during Fotopp: {e}")
            open("error.txt", "a").write(f"{self.cok}\n")
            return  # Skip if any error occurs in Fotopp

# Jalankan program
if __name__ == "__main__":
    os.system("clear")
    main = MAIN()
    main.approval()     
